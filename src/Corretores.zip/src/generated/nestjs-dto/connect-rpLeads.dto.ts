export class ConnectRpLeadsDto {
  id: string;
}
