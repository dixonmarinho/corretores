export class ConnectAgencySettingsDto {
  id: string;
}
