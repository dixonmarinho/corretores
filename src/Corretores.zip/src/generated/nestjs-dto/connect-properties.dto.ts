export class ConnectPropertiesDto {
  id: string;
}
