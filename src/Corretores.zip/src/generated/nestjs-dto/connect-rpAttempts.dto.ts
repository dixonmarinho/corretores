export class ConnectRpAttemptsDto {
  id?: string;
  path_link?: string;
}
