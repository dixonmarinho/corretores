export class ConnectRoDutyWindowsDto {
  id: string;
}
