export class ConnectAgenciesDto {
  id?: string;
  name?: string;
  crm_agency_id?: number;
}
