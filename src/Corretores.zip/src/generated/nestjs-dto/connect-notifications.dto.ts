export class ConnectNotificationsDto {
  id: string;
}
