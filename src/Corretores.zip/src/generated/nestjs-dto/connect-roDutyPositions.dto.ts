export class ConnectRoDutyPositionsDto {
  id: string;
}
