export class ConnectRoCustomizedQueuesDto {
  id: string;
}
