export class ConnectRpDealQueuesDto {
  id?: string;
  deal_id?: string;
}
