export class ConnectRoShiftTypesDto {
  id: string;
}
