export class ConnectRoShiftWindowsDto {
  id: string;
}
