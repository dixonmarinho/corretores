export class ConnectRoDutiesDto {
  id: string;
}
