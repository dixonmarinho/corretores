export class ConnectRpDealsExecutionsDto {
  id?: string;
  deal_id?: string;
}
