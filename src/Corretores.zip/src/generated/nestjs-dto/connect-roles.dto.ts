export class ConnectRolesDto {
  id?: string;
  name?: string;
}
