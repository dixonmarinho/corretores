export class ConnectRpDealsAgentsDto {
  id?: string;
  deal_id?: string;
  accepted_attempt_id?: string;
}
