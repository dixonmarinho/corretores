export class ConnectAgencyFallbackStrategiesDto {
  id: string;
}
