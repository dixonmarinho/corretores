export class ConnectRpDealsDto {
  id: string;
}
