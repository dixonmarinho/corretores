export class ConnectRoCustomizedPositionsDto {
  id: string;
}
