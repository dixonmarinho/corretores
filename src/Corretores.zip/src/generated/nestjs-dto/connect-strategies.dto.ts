export class ConnectStrategiesDto {
  id: string;
}
