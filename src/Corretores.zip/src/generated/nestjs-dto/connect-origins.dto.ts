export class ConnectOriginsDto {
  id: string;
}
