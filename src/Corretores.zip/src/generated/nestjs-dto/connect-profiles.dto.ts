export class ConnectProfilesDto {
  id?: string;
  crm_code?: number;
}
