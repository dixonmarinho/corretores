export class ConnectRoDailyDutiesDto {
  id: string;
}
